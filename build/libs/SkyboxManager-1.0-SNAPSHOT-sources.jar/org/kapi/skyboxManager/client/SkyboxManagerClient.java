package org.kapi.skyboxManager.client;

import org.kapi.skyboxManager.SkyboxManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class SkyboxManagerClient implements ClientModInitializer {
    private static class_304 keyBinding;

    @Override
    public void onInitializeClient() {
        keyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.skyboxmanager.open",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_K,
                class_304.class_11900.field_62556
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (keyBinding.method_1436()) {
                SkyboxManager.scanSkyboxFolders();
                client.method_1507(new SkyboxSelectorScreen());
            }
        });
    }
}