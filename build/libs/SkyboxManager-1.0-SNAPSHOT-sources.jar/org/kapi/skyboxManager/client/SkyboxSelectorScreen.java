package org.kapi.skyboxManager.client;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.kapi.skyboxManager.SkyboxManager;

public class SkyboxSelectorScreen extends class_437 {
    public SkyboxSelectorScreen() {
        super(class_2561.method_43470("Skybox Selector"));
    }

    @Override
    protected void method_57734(class_332 context) {
        // Pas de flou
    }

    @Override
    protected void method_25426() {
        for (int i = 0; i < SkyboxManager.skyboxFolders.size(); i++) {
            String name = SkyboxManager.skyboxFolders.get(i);
            int y = 40 + i * 25;
            this.method_37063(
                    class_4185.method_46430(class_2561.method_43470(name), button -> {
                        SkyboxTextureManager.loadSkybox(name, SkyboxManager.configDir);
                        this.method_25419();
                    }).method_46434(this.field_22789 / 2 - 100, y, 200, 20).method_46431()
            );
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25296(0, 0, this.field_22789, this.field_22790, 0x80000000, 0x80000000);
        context.method_27534(
                this.field_22793,
                this.field_22785,
                this.field_22789 / 2,
                15,
                0xFFFFFF
        );
        super.method_25394(context, mouseX, mouseY, delta);
    }
}