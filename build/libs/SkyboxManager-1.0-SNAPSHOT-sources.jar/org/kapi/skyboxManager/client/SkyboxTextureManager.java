package org.kapi.skyboxManager.client;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class SkyboxTextureManager {
    public static final Map<String, class_2960> SKYBOX_TEXTURES = new HashMap<>();
    private static final String[] FACES = {"top", "bottom", "north", "south", "east", "west"};

    public static void loadSkybox(String folderName, Path configPath) {
        // Détruire les anciennes textures
        SKYBOX_TEXTURES.forEach((face, id) ->
                class_310.method_1551()
                        .method_1531()
                        .method_4615(id)
        );
        SKYBOX_TEXTURES.clear();

        File folder = configPath.resolve(folderName).toFile();

        for (String face : FACES) {
            File file = new File(folder, face + ".png");
            if (!file.exists()) continue;

            try (FileInputStream is = new FileInputStream(file)) {
                class_1011 image = class_1011.method_4309(is);
                class_1043 texture = new class_1043(
                        () -> "skybox-manager:" + face, image
                );
                class_2960 texId = class_2960.method_60655("skybox-manager", "dynamic_" + face);
                class_310.method_1551()
                        .method_1531()
                        .method_4616(texId, texture);
                SKYBOX_TEXTURES.put(face, texId);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        System.out.println("Loaded textures: " + SKYBOX_TEXTURES.size());
        SKYBOX_TEXTURES.forEach((k, v) -> System.out.println("  " + k + " -> " + v));
    }
}