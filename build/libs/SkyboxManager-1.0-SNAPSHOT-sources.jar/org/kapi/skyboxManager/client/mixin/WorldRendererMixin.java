package org.kapi.skyboxManager.client.mixin;

import com.mojang.blaze3d.vertex.VertexFormat;
import org.kapi.skyboxManager.client.SkyboxTextureManager;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.textures.GpuTextureView;
import net.minecraft.class_1044;
import net.minecraft.class_10799;
import net.minecraft.class_276;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_761;
import net.minecraft.class_9799;
import net.minecraft.class_9801;
import net.minecraft.class_9909;
import net.minecraft.class_9916;
import net.minecraft.class_9925;
import net.minecraft.class_9960;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.OptionalDouble;
import java.util.OptionalInt;

@Mixin(class_761.class)
public class WorldRendererMixin {

    @Shadow
    private class_9960 framebufferSet;

    @Inject(
            method = "renderSky(Lnet/minecraft/client/render/FrameGraphBuilder;Lnet/minecraft/client/render/Camera;Lcom/mojang/blaze3d/buffers/GpuBufferSlice;)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void onRenderSky(class_9909 frameGraphBuilder, class_4184 camera,
                             GpuBufferSlice fogBuffer, CallbackInfo ci) {
        if (SkyboxTextureManager.SKYBOX_TEXTURES.size() < 6) return;
        ci.cancel();

        class_9916 framePass = frameGraphBuilder.method_61911("custom_skybox");
        this.framebufferSet.field_53091 = framePass.method_61933(this.framebufferSet.field_53091);
        class_9925<class_276> handle = this.framebufferSet.field_53091;

        framePass.method_61929(() -> {
            class_276 fb = handle.get();
            GpuTextureView colorView = fb.method_71639();
            GpuTextureView depthView = fb.method_71640();
            renderSkybox(colorView, depthView);
        });
    }

    private void renderSkybox(GpuTextureView colorView, GpuTextureView depthView) {
        String[] faces = {"north", "south", "west", "east", "top", "bottom"};
        float s = 100.0F;

        RenderSystem.class_5590 indexBuffer = RenderSystem.getSequentialBuffer(VertexFormat.class_5596.field_27382);
        GpuBuffer ib = indexBuffer.method_68274(6);

        for (String face : faces) {
            class_2960 id = SkyboxTextureManager.SKYBOX_TEXTURES.get(face);
            if (id == null) continue;

            class_1044 abstractTexture = class_310.method_1551()
                    .method_1531().method_4619(id);
            if (abstractTexture == null) continue;

            GpuTextureView view = abstractTexture.method_71659();

            int vertexSize = class_290.field_1585.getVertexSize();
            try (class_9799 allocator = class_9799.method_72201(4 * vertexSize)) {
                class_287 bufferBuilder = new class_287(allocator, VertexFormat.class_5596.field_27382, class_290.field_1585);
                Matrix4f matrix = new Matrix4f();

                switch (face) {
                    case "north" -> {
                        bufferBuilder.method_22918(matrix, -s, -s, -s).method_22913(0f, 1f);
                        bufferBuilder.method_22918(matrix,  s, -s, -s).method_22913(1f, 1f);
                        bufferBuilder.method_22918(matrix,  s,  s, -s).method_22913(1f, 0f);
                        bufferBuilder.method_22918(matrix, -s,  s, -s).method_22913(0f, 0f);
                    }
                    case "south" -> {
                        bufferBuilder.method_22918(matrix,  s, -s,  s).method_22913(0f, 1f);
                        bufferBuilder.method_22918(matrix, -s, -s,  s).method_22913(1f, 1f);
                        bufferBuilder.method_22918(matrix, -s,  s,  s).method_22913(1f, 0f);
                        bufferBuilder.method_22918(matrix,  s,  s,  s).method_22913(0f, 0f);
                    }
                    case "west" -> {
                        bufferBuilder.method_22918(matrix, -s, -s,  s).method_22913(0f, 1f);
                        bufferBuilder.method_22918(matrix, -s, -s, -s).method_22913(1f, 1f);
                        bufferBuilder.method_22918(matrix, -s,  s, -s).method_22913(1f, 0f);
                        bufferBuilder.method_22918(matrix, -s,  s,  s).method_22913(0f, 0f);
                    }
                    case "east" -> {
                        bufferBuilder.method_22918(matrix,  s, -s, -s).method_22913(0f, 1f);
                        bufferBuilder.method_22918(matrix,  s, -s,  s).method_22913(1f, 1f);
                        bufferBuilder.method_22918(matrix,  s,  s,  s).method_22913(1f, 0f);
                        bufferBuilder.method_22918(matrix,  s,  s, -s).method_22913(0f, 0f);
                    }
                    case "top" -> {
                        bufferBuilder.method_22918(matrix, -s,  s, -s).method_22913(0f, 0f);
                        bufferBuilder.method_22918(matrix,  s,  s, -s).method_22913(1f, 0f);
                        bufferBuilder.method_22918(matrix,  s,  s,  s).method_22913(1f, 1f);
                        bufferBuilder.method_22918(matrix, -s,  s,  s).method_22913(0f, 1f);
                    }
                    case "bottom" -> {
                        bufferBuilder.method_22918(matrix, -s, -s,  s).method_22913(0f, 1f);
                        bufferBuilder.method_22918(matrix,  s, -s,  s).method_22913(1f, 1f);
                        bufferBuilder.method_22918(matrix,  s, -s, -s).method_22913(1f, 0f);
                        bufferBuilder.method_22918(matrix, -s, -s, -s).method_22913(0f, 0f);
                    }
                }

                try (class_9801 builtBuffer = bufferBuilder.method_60800()) {
                    GpuBuffer gpuBuffer = RenderSystem.getDevice().createBuffer(
                            () -> "Skybox " + face, 40, builtBuffer.method_60818()
                    );

                    GpuBufferSlice transforms = RenderSystem.getDynamicUniforms().method_71106(
                            RenderSystem.getModelViewMatrix(),
                            new Vector4f(1f, 1f, 1f, 1f),
                            new Vector3f(),
                            new Matrix4f(),
                            0f
                    );

                    try (RenderPass renderPass = RenderSystem.getDevice().createCommandEncoder()
                            .createRenderPass(() -> "Skybox " + face, colorView, OptionalInt.empty(), depthView, OptionalDouble.empty())) {
                        renderPass.setPipeline(class_10799.field_56878);
                        RenderSystem.bindDefaultUniforms(renderPass);
                        renderPass.setUniform("DynamicTransforms", transforms);
                        renderPass.bindSampler("Sampler0", view);
                        renderPass.setVertexBuffer(0, gpuBuffer);
                        renderPass.setIndexBuffer(ib, indexBuffer.method_31924());
                        renderPass.drawIndexed(0, 0, 6, 1);
                    }

                    gpuBuffer.close();
                }
            }
        }
    }
}